# Changelog

## [1.0.0] — 2026-10-02
### Añadido
- Aplicación de escritorio (Electron) para macOS, Windows y Linux.
- Checklist 5S × Resolución 2674 de 2013 con 40 ítems vinculados a artículo y capítulo.
- Diagnóstico con radar 5S y semáforo por capítulo; comparación con línea base.
- Plan de acción priorizado por impacto sanitario × facilidad.
- Generador del plan de saneamiento (Art. 26) con guardado nativo y exportación a PDF.
- Tablero territorial del piloto (20 panaderías: Sabana de Occidente, Bogotá, Soacha).
- Asistente guiado por reglas; integración con modelo de lenguaje cuando el entorno lo provee.
- Datos del piloto en JSON y CSV, con script reproducible de generación.
- Flujo de GitHub Actions que compila el DMG automáticamente.
