// Puente seguro entre la interfaz (src/index.html) y el sistema operativo
const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("pania", {
  saveDocument: (filename, html) => ipcRenderer.invoke("pania:saveDocument", filename, html),
  printToPDF: (filename) => ipcRenderer.invoke("pania:printToPDF", filename),
  platform: process.platform,
  version: "1.0.0",
});
