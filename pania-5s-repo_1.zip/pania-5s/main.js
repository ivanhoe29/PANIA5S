// PanIA 5S — proceso principal de Electron
const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require("electron");
const path = require("path");
const fs = require("fs");

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 390,
    minHeight: 640,
    title: "PanIA 5S",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, "src", "index.html"));
  // Abrir enlaces externos en el navegador del sistema
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http")) shell.openExternal(url);
    return { action: "deny" };
  });
}

// Guardar el plan de saneamiento con el diálogo nativo
ipcMain.handle("pania:saveDocument", async (event, filename, html) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: "Guardar plan de saneamiento",
    defaultPath: path.join(app.getPath("documents"), filename),
    filters: [{ name: "Documento HTML (imprimible a PDF)", extensions: ["html"] }],
  });
  if (canceled || !filePath) return { ok: false };
  fs.writeFileSync(filePath, html, "utf8");
  return { ok: true, path: filePath };
});

// Imprimir / exportar a PDF
ipcMain.handle("pania:printToPDF", async (event, filename) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: "Exportar a PDF",
    defaultPath: path.join(app.getPath("documents"), filename.replace(/\.html$/, ".pdf")),
    filters: [{ name: "PDF", extensions: ["pdf"] }],
  });
  if (canceled || !filePath) return { ok: false };
  const data = await win.webContents.printToPDF({ printBackground: true, pageSize: "Letter" });
  fs.writeFileSync(filePath, data);
  return { ok: true, path: filePath };
});

app.whenReady().then(() => {
  const template = [
    ...(process.platform === "darwin" ? [{ role: "appMenu" }] : []),
    { role: "fileMenu" },
    { role: "editMenu" },
    { role: "viewMenu" },
    { role: "windowMenu" },
    { role: "help", submenu: [{ label: "Repositorio en GitHub", click: () => shell.openExternal("https://github.com/irozo/pania-5s") }, { label: "Resolución 2674 de 2013 (INVIMA)", click: () => shell.openExternal("https://normograma.invima.gov.co/compilacion/docs/resolucion_minsaludps_2674_2013.htm") }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
  createWindow();
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
