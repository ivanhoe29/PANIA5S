import json, random
random.seed(2674)

# 40 checklist items: 8 per S, mapped to Res. 2674/2013 chapters & articles
S = ["seiri","seiton","seiso","seiketsu","shitsuke"]
items = [
 # SEIRI — Clasificar (materias primas, insumos, lo innecesario)
 ("seiri","fabricacion","Art. 16","¿Las materias primas e insumos están clasificados y separados de productos no conformes o vencidos?",3,3),
 ("seiri","fabricacion","Art. 16","¿Existe un área definida para materias primas rechazadas o devueltas?",2,3),
 ("seiri","fabricacion","Art. 17","¿Los envases y empaques se almacenan separados de materias primas y productos?",2,3),
 ("seiri","edificacion","Art. 6","¿Se han retirado del área de producción objetos, equipos o materiales que no se usan?",2,3),
 ("seiri","fabricacion","Art. 16","¿Se aplica el principio PEPS (primero en entrar, primero en salir) en el almacenamiento?",3,2),
 ("seiri","saneamiento","Art. 26","¿Los residuos sólidos están separados en la fuente (orgánicos, reciclables, ordinarios)?",2,3),
 ("seiri","fabricacion","Art. 16","¿Los productos químicos de limpieza están separados y alejados de alimentos?",3,3),
 ("seiri","equipos","Art. 8","¿Los utensilios en mal estado se han retirado del uso?",2,3),
 # SEITON — Ordenar (distribución de áreas, flujo, identificación)
 ("seiton","edificacion","Art. 6","¿Las áreas de recepción, producción, empaque y venta están separadas y señalizadas?",3,2),
 ("seiton","edificacion","Art. 7","¿El flujo del proceso evita cruces entre producto crudo y producto terminado?",3,1),
 ("seiton","fabricacion","Art. 16","¿Las materias primas están almacenadas sobre estibas o estantes, separadas del piso y la pared?",2,3),
 ("seiton","fabricacion","Art. 16","¿Los insumos están rotulados con nombre, fecha de ingreso y vencimiento?",2,3),
 ("seiton","equipos","Art. 9","¿Los equipos están ubicados permitiendo la limpieza y circulación del personal?",2,2),
 ("seiton","edificacion","Art. 7","¿Los baños y vestidores están separados del área de producción?",3,1),
 ("seiton","equipos","Art. 10","¿Los utensilios tienen un lugar asignado e identificado?",1,3),
 ("seiton","saneamiento","Art. 26","¿Los recipientes de residuos están identificados y ubicados fuera del área de proceso?",2,3),
 # SEISO — Limpiar (saneamiento, limpieza y desinfección)
 ("seiso","saneamiento","Art. 26","¿Existe un programa documentado de limpieza y desinfección?",3,2),
 ("seiso","saneamiento","Art. 26","¿Se registran las actividades de limpieza y desinfección realizadas?",2,3),
 ("seiso","edificacion","Art. 7","¿Pisos, paredes y techos están limpios, sin grietas ni acumulación de residuos?",3,2),
 ("seiso","equipos","Art. 10","¿Equipos y utensilios se limpian y desinfectan después de cada uso?",3,3),
 ("seiso","saneamiento","Art. 26","¿Existe un programa documentado de control integrado de plagas?",3,2),
 ("seiso","saneamiento","Art. 26","¿Hay evidencia de ausencia de plagas (sin excrementos, nidos o insectos)?",3,2),
 ("seiso","saneamiento","Art. 26","¿Existe programa de manejo de residuos sólidos y se cumple la frecuencia de evacuación?",2,3),
 ("seiso","saneamiento","Art. 26","¿Se dispone de agua potable y se verifica su calidad (cloro residual)?",3,2),
 # SEIKETSU — Estandarizar (aseguramiento y control de calidad)
 ("seiketsu","aseguramiento","Art. 22","¿Existen procedimientos escritos para los procesos críticos (amasado, horneado, enfriamiento)?",2,2),
 ("seiketsu","aseguramiento","Art. 23","¿Se llevan registros de control de temperatura de horneado y almacenamiento?",2,3),
 ("seiketsu","aseguramiento","Art. 24","¿Las materias primas tienen ficha técnica o certificado del proveedor?",2,2),
 ("seiketsu","fabricacion","Art. 19","¿El producto terminado se rotula con fecha de elaboración y vencimiento?",2,3),
 ("seiketsu","aseguramiento","Art. 22","¿Existe un plan de saneamiento documentado con los 4 programas?",3,2),
 ("seiketsu","fabricacion","Art. 20","¿Se controla el enfriamiento del producto antes del empaque?",2,3),
 ("seiketsu","aseguramiento","Art. 23","¿Existen formatos de verificación diaria de condiciones higiénicas?",1,3),
 ("seiketsu","aseguramiento","Art. 24","¿Se manejan registros de trazabilidad por lote de producción?",2,2),
 # SHITSUKE — Disciplina (personal manipulador, capacitación)
 ("shitsuke","personal","Art. 11","¿El personal manipulador cuenta con certificado médico vigente (anual)?",3,2),
 ("shitsuke","personal","Art. 12","¿El personal tiene certificado de capacitación en manipulación de alimentos vigente?",3,2),
 ("shitsuke","personal","Art. 13","¿El personal usa dotación completa: gorro, tapabocas, uniforme claro y calzado cerrado?",3,3),
 ("shitsuke","personal","Art. 13","¿El personal mantiene uñas cortas, sin esmalte, sin joyas ni accesorios?",2,3),
 ("shitsuke","personal","Art. 13","¿Existe un lavamanos de accionamiento no manual con jabón y toallas desechables?",3,2),
 ("shitsuke","personal","Art. 12","¿Hay un plan de capacitación continua documentado para el personal?",2,2),
 ("shitsuke","personal","Art. 13","¿Se prohíbe comer, fumar o usar celular en el área de producción y se cumple?",2,3),
 ("shitsuke","personal","Art. 13","¿El personal visitante usa dotación al ingresar al área de proceso?",1,3),
]
ITEMS=[]
for i,(s,ch,art,text,impacto,facilidad) in enumerate(items):
    ITEMS.append({"id":f"i{i+1:02d}","s":s,"ch":ch,"art":art,"text":text,"impacto":impacto,"facilidad":facilidad})

bakeries = [
 ("La Espiga Dorada","Madrid","Sabana de Occidente",4,2),
 ("Pan y Café Doña Rosa","Madrid","Sabana de Occidente",3,1),
 ("El Trigal","Mosquera","Sabana de Occidente",6,3),
 ("Delicias del Sol","Mosquera","Sabana de Occidente",2,2),
 ("Panificadora San José","Facatativá","Sabana de Occidente",8,3),
 ("Las Delicias","Facatativá","Sabana de Occidente",3,2),
 ("Pan Casero La Abuela","Funza","Sabana de Occidente",2,1),
 ("Tres Hornos","Funza","Sabana de Occidente",5,2),
 ("Mi Barrio","Kennedy","Bogotá",3,2),
 ("La Francesa de Kennedy","Kennedy","Bogotá",5,3),
 ("El Buen Pan","Kennedy","Bogotá",2,1),
 ("Pan de Casa","Engativá","Bogotá",4,2),
 ("Los Alpes","Engativá","Bogotá",6,3),
 ("Doña Flor","Engativá","Bogotá",2,2),
 ("El Horno Rojo","Ciudad Bolívar","Bogotá",3,1),
 ("La Bendición","Ciudad Bolívar","Bogotá",2,1),
 ("Pan Sabroso","Ciudad Bolívar","Bogotá",4,2),
 ("San Mateo","Soacha","Soacha",3,1),
 ("La Esperanza","Soacha","Soacha",2,2),
 ("Compartir","Soacha","Soacha",5,2),
]
# baseline by stratum: lower stratum -> lower baseline
BAK=[]
for i,(name,mun,prov,emp,estrato) in enumerate(bakeries):
    base = {1:0.36,2:0.45,3:0.56}[estrato] + random.uniform(-0.07,0.07)
    pre={}; post={}
    for it in ITEMS:
        r=random.random()
        # pre: 2=cumple,1=parcial,0=no
        if r < base*0.75: v=2
        elif r < base*0.75+0.28: v=1
        else: v=0
        pre[it["id"]]=v
        # post: improvement prob depends on facilidad
        pimp = {1:0.30,2:0.55,3:0.78}[it["facilidad"]]
        nv=v
        if v<2 and random.random()<pimp:
            nv = v+1 if (v==0 and random.random()<0.45) else 2
        if v==2 and random.random()<0.04: nv=1
        post[it["id"]]=nv
    BAK.append({"id":f"b{i+1:02d}","name":"Panadería "+name,"mun":mun,"prov":prov,"emp":emp,"estrato":estrato,
                "owner":random.choice(["Luz Marina","Jairo","Rosa Elena","Carlos Andrés","Gloria","Edilberto","Nubia","Fabián","Amparo","Wilson"]),
                "pre":pre,"post":post})

def score(ans): return round(100*sum(ans.values())/(2*len(ans)),1)
pres=[score(b["pre"]) for b in BAK]; posts=[score(b["post"]) for b in BAK]
print("avg pre",round(sum(pres)/20,1),"avg post",round(sum(posts)/20,1), "rel", round((sum(posts)/sum(pres)-1)*100,1))
for b in BAK: print(b["name"],b["mun"],score(b["pre"]),score(b["post"]))
json.dump({"items":ITEMS,"bakeries":BAK},open("data.json","w"),ensure_ascii=False)
