# Guía de contribución

Gracias por tu interés en PanIA 5S. Este proyecto nace en UNIMINUTO (Misión 4: IA para la equidad)
y está pensado para que estudiantes, docentes y organizaciones del territorio lo mejoren.

## Cómo contribuir
1. Haz un *fork* y crea una rama: `git checkout -b feature/mi-mejora`.
2. Cambios en la interfaz: edita `src/index.html` (HTML + CSS + JS en un solo archivo, sin dependencias).
3. Cambios en los ítems del checklist o en los datos del piloto: edita `data/generar_datos.py` y ejecuta `npm run data`;
   luego actualiza la constante `DATA` en `src/index.html` con el contenido de `data/datos_piloto.json`.
4. Prueba en escritorio (`npm start`) y en navegador (`npm run web`).
5. Abre un *pull request* describiendo el cambio y, si aplica, el artículo de la Resolución 2674 de 2013 que sustenta un nuevo ítem.

## Reglas para nuevos ítems del checklist
- Cada ítem debe citar el artículo de la Resolución 2674 de 2013 que lo exige.
- Debe asignarse a una sola S (seiri, seiton, seiso, seiketsu, shitsuke) y a un capítulo.
- Debe tener `impacto` (1–3) y `facilidad` (1–3); así lo usa el motor de priorización.

## Código de conducta
Trato respetuoso, lenguaje inclusivo y foco en el microempresario que usará la herramienta.
